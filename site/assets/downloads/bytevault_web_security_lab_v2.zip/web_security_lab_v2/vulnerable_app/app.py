
from flask import Flask, render_template, request, redirect, session, url_for, abort
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "bytevault123"  # intentionally weak/hard-coded
DB = Path(__file__).with_name("bytevault.db")

PRODUCTS = [
    (1,"Nebula Mechanical Keyboard","Periféricos","Switches táctiles, RGB y construcción compacta.",699.00,"⌨️"),
    (2,"Orbit 27” QHD Monitor","Monitores","Panel QHD de 165 Hz para gaming y productividad.",2499.00,"🖥️"),
    (3,"Pulse Wireless Headset","Audio","Audio envolvente, micrófono desmontable y baja latencia.",849.00,"🎧"),
    (4,"Vector Pro Mouse","Periféricos","Sensor preciso, peso ultraligero y memoria integrada.",429.00,"🖱️"),
    (5,"Vault Mini PC","Computadoras","Mini PC compacto para desarrollo, oficina y laboratorio.",3899.00,"💻"),
    (6,"Aero USB-C Hub","Accesorios","Hub 7-en-1 con HDMI, Ethernet, USB y lector SD.",479.00,"🔌"),
]

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c=db(); cur=c.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS users; DROP TABLE IF EXISTS products; DROP TABLE IF EXISTS reviews; DROP TABLE IF EXISTS orders;
    CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, full_name TEXT, email TEXT);
    CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT, category TEXT, description TEXT, price REAL, icon TEXT);
    CREATE TABLE reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, author TEXT, body TEXT);
    CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, total REAL, status TEXT, created_at TEXT);
    """)
    cur.executemany("INSERT INTO users(username,password,full_name,email) VALUES(?,?,?,?)",[
        ("admin","admin123","Administrador ByteVault","admin@bytevault.local"),
        ("ana","123456","Ana López","ana@bytevault.local"),
        ("carlos","password","Carlos Pérez","carlos@bytevault.local")
    ])
    cur.executemany("INSERT INTO products VALUES(?,?,?,?,?,?)",PRODUCTS)
    cur.executemany("INSERT INTO reviews(author,body) VALUES(?,?)",[
        ("María","El monitor se ve excelente y el diseño está chilero."),
        ("Diego","El teclado se siente muy bien para programar.")
    ])
    cur.executemany("INSERT INTO orders(user_id,total,status,created_at) VALUES(?,?,?,?)",[
        (1,3198.00,"ENTREGADO","2026-08-12"),(1,849.00,"EN CAMINO","2026-08-24"),
        (2,699.00,"ENTREGADO","2026-08-18"),(3,4378.00,"PROCESANDO","2026-08-27")
    ])
    c.commit(); c.close()

@app.route("/")
def index():
    c=db(); products=c.execute("SELECT * FROM products LIMIT 3").fetchall(); c.close()
    return render_template("index.html",products=products)

@app.route("/catalog")
def catalog():
    q=request.args.get("q","")
    c=db()
    # intentionally vulnerable SQL concatenation
    sql=f"SELECT * FROM products WHERE name LIKE '%{q}%' OR category LIKE '%{q}%' OR description LIKE '%{q}%'"
    products=c.execute(sql).fetchall(); c.close()
    return render_template("catalog.html",products=products,q=q)

@app.route("/product/<int:product_id>")
def product(product_id):
    c=db(); p=c.execute(f"SELECT * FROM products WHERE id={product_id}").fetchone(); c.close()
    if not p: abort(404)
    return render_template("product.html",product=p)

@app.route("/login",methods=["GET","POST"])
def login():
    error=None
    if request.method=="POST":
        username=request.form.get("username","")
        password=request.form.get("password","")
        # intentionally vulnerable SQL injection + plaintext password storage
        sql=f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
        c=db(); u=c.execute(sql).fetchone(); c.close()
        if u:
            session["user"]={"id":u["id"],"username":u["username"],"full_name":u["full_name"]}
            return redirect(url_for("index"))
        error="Credenciales inválidas"
    return render_template("login.html",error=error,csrf=False,demo_user="admin",demo_pass="admin123")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/reviews",methods=["GET","POST"])
def reviews():
    c=db()
    if request.method=="POST":
        author=request.form.get("author","Anónimo")
        body=request.form.get("body","")
        c.execute("INSERT INTO reviews(author,body) VALUES(?,?)",(author,body)); c.commit()
    rows=c.execute("SELECT * FROM reviews ORDER BY id DESC").fetchall(); c.close()
    return render_template("reviews.html",reviews=rows)

@app.route("/profile/<int:user_id>")
def profile(user_id):
    # intentionally vulnerable IDOR
    c=db(); u=c.execute(f"SELECT id,username,full_name,email FROM users WHERE id={user_id}").fetchone(); c.close()
    if not u: abort(404)
    return render_template("profile.html",user=u)

@app.route("/orders")
def orders():
    if "user" not in session: return redirect(url_for("login"))
    c=db()
    rows=c.execute(f"SELECT * FROM orders WHERE user_id={session['user']['id']} ORDER BY id DESC").fetchall()
    c.close(); return render_template("orders.html",orders=rows)

@app.route("/order/<int:order_id>")
def order_detail(order_id):
    # intentionally vulnerable IDOR: does not verify order ownership
    c=db()
    row=c.execute(f"""SELECT o.*,u.full_name,u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id={order_id}""").fetchone()
    c.close()
    if not row: abort(404)
    return render_template("order_detail.html",order=row)

@app.route("/reset")
def reset():
    # intentionally unsafe state-changing GET without auth/CSRF
    init_db()
    return "Laboratorio reiniciado."

if __name__=="__main__":
    if not DB.exists(): init_db()
    app.run(host="127.0.0.1",port=5000,debug=True)
