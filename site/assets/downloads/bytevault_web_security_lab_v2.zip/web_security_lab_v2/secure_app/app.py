
from flask import Flask, render_template, request, redirect, session, url_for, abort
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, secrets, time
from pathlib import Path

app=Flask(__name__)
app.secret_key=os.environ.get("BYTEVAULT_SECRET") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE="Lax")
DB=Path(__file__).with_name("bytevault.db")
LOGIN_ATTEMPTS={}

PRODUCTS = [
    (1,"Nebula Mechanical Keyboard","Periféricos","Switches táctiles, RGB y construcción compacta.",699.00,"⌨️"),
    (2,"Orbit 27” QHD Monitor","Monitores","Panel QHD de 165 Hz para gaming y productividad.",2499.00,"🖥️"),
    (3,"Pulse Wireless Headset","Audio","Audio envolvente, micrófono desmontable y baja latencia.",849.00,"🎧"),
    (4,"Vector Pro Mouse","Periféricos","Sensor preciso, peso ultraligero y memoria integrada.",429.00,"🖱️"),
    (5,"Vault Mini PC","Computadoras","Mini PC compacto para desarrollo, oficina y laboratorio.",3899.00,"💻"),
    (6,"Aero USB-C Hub","Accesorios","Hub 7-en-1 con HDMI, Ethernet, USB y lector SD.",479.00,"🔌"),
]

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def csrf_token():
    if "_csrf" not in session: session["_csrf"]=secrets.token_urlsafe(32)
    return session["_csrf"]
app.jinja_env.globals["csrf_token"]=csrf_token

def require_csrf():
    sent=request.form.get("_csrf","")
    saved=session.get("_csrf","")
    if not saved or not secrets.compare_digest(sent,saved): abort(400,"CSRF inválido")

def init_db():
    c=db();cur=c.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS users; DROP TABLE IF EXISTS products; DROP TABLE IF EXISTS reviews; DROP TABLE IF EXISTS orders;
    CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, full_name TEXT, email TEXT);
    CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT, category TEXT, description TEXT, price REAL, icon TEXT);
    CREATE TABLE reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, author TEXT, body TEXT);
    CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, total REAL, status TEXT, created_at TEXT);
    """)
    users=[
      ("admin",generate_password_hash("Cambiame123!"),"Administrador ByteVault","admin@bytevault.local"),
      ("ana",generate_password_hash("AnaSegura123!"),"Ana López","ana@bytevault.local"),
      ("carlos",generate_password_hash("CarlosSegura123!"),"Carlos Pérez","carlos@bytevault.local")
    ]
    cur.executemany("INSERT INTO users(username,password_hash,full_name,email) VALUES(?,?,?,?)",users)
    cur.executemany("INSERT INTO products VALUES(?,?,?,?,?,?)",PRODUCTS)
    cur.executemany("INSERT INTO reviews(author,body) VALUES(?,?)",[
        ("María","El monitor se ve excelente y el diseño está chilero."),
        ("Diego","El teclado se siente muy bien para programar.")
    ])
    cur.executemany("INSERT INTO orders(user_id,total,status,created_at) VALUES(?,?,?,?)",[
        (1,3198.00,"ENTREGADO","2026-08-12"),(1,849.00,"EN CAMINO","2026-08-24"),
        (2,699.00,"ENTREGADO","2026-08-18"),(3,4378.00,"PROCESANDO","2026-08-27")
    ])
    c.commit();c.close()

@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"]="nosniff"
    resp.headers["X-Frame-Options"]="DENY"
    resp.headers["Referrer-Policy"]="no-referrer"
    resp.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self' 'unsafe-inline'"
    resp.headers["Permissions-Policy"]="camera=(), microphone=(), geolocation=()"
    resp.headers["Cache-Control"]="no-store"
    return resp

@app.route("/")
def index():
    c=db();products=c.execute("SELECT * FROM products LIMIT 3").fetchall();c.close()
    return render_template("index.html",products=products)

@app.route("/catalog")
def catalog():
    q=request.args.get("q","").strip()[:100]
    c=db()
    like=f"%{q}%"
    products=c.execute("SELECT * FROM products WHERE name LIKE ? OR category LIKE ? OR description LIKE ?",(like,like,like)).fetchall()
    c.close()
    return render_template("catalog.html",products=products,q=q)

@app.route("/product/<int:product_id>")
def product(product_id):
    c=db();p=c.execute("SELECT * FROM products WHERE id=?",(product_id,)).fetchone();c.close()
    if not p: abort(404)
    return render_template("product.html",product=p)

@app.route("/login",methods=["GET","POST"])
def login():
    error=None
    if request.method=="POST":
        require_csrf()
        key=request.remote_addr or "local"
        now=time.time()
        recent=[t for t in LOGIN_ATTEMPTS.get(key,[]) if now-t<60]
        if len(recent)>=8:
            error="Demasiados intentos. Espera un minuto."
            LOGIN_ATTEMPTS[key]=recent
            return render_template("login.html",error=error,csrf=True,demo_user="admin",demo_pass="Cambiame123!")
        recent.append(now);LOGIN_ATTEMPTS[key]=recent
        username=request.form.get("username","").strip()[:50]
        password=request.form.get("password","")
        c=db();u=c.execute("SELECT * FROM users WHERE username=?",(username,)).fetchone();c.close()
        if u and check_password_hash(u["password_hash"],password):
            session.clear()
            session["user"]={"id":u["id"],"username":u["username"],"full_name":u["full_name"]}
            return redirect(url_for("index"))
        error="Credenciales inválidas"
    return render_template("login.html",error=error,csrf=True,demo_user="admin",demo_pass="Cambiame123!")

@app.route("/logout",methods=["POST"])
def logout():
    require_csrf();session.clear();return redirect(url_for("index"))

@app.route("/reviews",methods=["GET","POST"])
def reviews():
    c=db()
    if request.method=="POST":
        require_csrf()
        author=request.form.get("author","Anónimo").strip()[:60]
        body=request.form.get("body","").strip()[:500]
        if body:
            c.execute("INSERT INTO reviews(author,body) VALUES(?,?)",(author,body));c.commit()
    rows=c.execute("SELECT * FROM reviews ORDER BY id DESC").fetchall();c.close()
    return render_template("reviews.html",reviews=rows)

@app.route("/profile")
def profile():
    if "user" not in session:return redirect(url_for("login"))
    c=db();u=c.execute("SELECT id,username,full_name,email FROM users WHERE id=?",(session["user"]["id"],)).fetchone();c.close()
    return render_template("profile.html",user=u)

@app.route("/orders")
def orders():
    if "user" not in session:return redirect(url_for("login"))
    c=db();rows=c.execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC",(session["user"]["id"],)).fetchall();c.close()
    return render_template("orders.html",orders=rows)

@app.route("/order/<int:order_id>")
def order_detail(order_id):
    if "user" not in session:return redirect(url_for("login"))
    c=db()
    row=c.execute("""SELECT o.*,u.full_name,u.email FROM orders o JOIN users u ON u.id=o.user_id
                     WHERE o.id=? AND o.user_id=?""",(order_id,session["user"]["id"])).fetchone()
    c.close()
    if not row: abort(404)
    return render_template("order_detail.html",order=row)

@app.route("/reset",methods=["POST"])
def reset():
    if "user" not in session or session["user"]["username"]!="admin":abort(403)
    require_csrf();init_db();session.clear();return redirect(url_for("index"))

if __name__=="__main__":
    if not DB.exists():init_db()
    app.run(host="127.0.0.1",port=5001,debug=False)
