# ByteVault Web Security Lab v2

Dos aplicaciones visualmente equivalentes para una práctica de Seguridad y Auditoría de Sistemas.

## 1. vulnerable_app
Puerto por defecto: `5000`

Incluye intencionalmente:
- SQL Injection en login.
- SQL Injection en búsqueda del catálogo.
- Stored XSS en reseñas.
- IDOR / Broken Access Control en perfiles.
- IDOR / Broken Access Control en pedidos.
- Contraseñas en texto plano.
- Secret key débil y hard-coded.
- Ausencia de protección CSRF.
- Logout mediante GET.
- Reset sensible mediante GET sin autenticación.
- Falta de security headers.
- Debug mode habilitado.

Credenciales:
- `admin / admin123`
- `ana / 123456`
- `carlos / password`

## 2. secure_app
Puerto por defecto: `5001`

Controles:
- SQL parametrizado.
- Password hashing con Werkzeug.
- Escape HTML automático.
- Acceso al perfil basado en la sesión.
- Verificación de propiedad de pedidos.
- CSRF en operaciones POST.
- Logout por POST.
- Reset restringido a admin y protegido por CSRF.
- Security headers.
- Session secret no hard-coded.
- Rate limit básico del login.
- Debug deshabilitado.

Credenciales:
- `admin / Cambiame123!`
- `ana / AnaSegura123!`
- `carlos / CarlosSegura123!`

## Ejecución en Kali / WSL

Vulnerable:
```bash
cd vulnerable_app
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Segura:
```bash
cd secure_app
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Si Windows no puede abrir `127.0.0.1` de WSL, levanta Flask escuchando en todas las interfaces:

Vulnerable:
```bash
python -m flask --app app run --host=0.0.0.0 --port=5000
```

Segura:
```bash
python -m flask --app app run --host=0.0.0.0 --port=5001
```

Obtén la IP de WSL con:
```bash
hostname -I
```

Luego abre en Windows:
`http://IP_DE_WSL:5000`
o
`http://IP_DE_WSL:5001`

## Objetivo académico
Escanear ambas versiones con las mismas herramientas y comparar resultados:
- WhatWeb
- Nikto
- Nmap
- OWASP ZAP
- Pruebas manuales controladas

No publiques la aplicación vulnerable en Internet.
